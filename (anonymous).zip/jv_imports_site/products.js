/* Edite este arquivo para cadastrar produtos reais e seus links de afiliado. */
const PRODUCTS = [
  {
    "id": "casa-01",
    "name": "Organizador multiuso",
    "category": "Casa e cozinha",
    "description": "Ideia prática para organizar espaços e facilitar a rotina.",
    "price": "Consulte o preço",
    "affiliateUrl": "",
    "symbol": "⌂"
  },
  {
    "id": "casa-02",
    "name": "Acessório para cozinha",
    "category": "Casa e cozinha",
    "description": "Utensílio funcional para o dia a dia da cozinha.",
    "price": "Consulte o preço",
    "affiliateUrl": "",
    "symbol": "✦"
  },
  {
    "id": "eletro-01",
    "name": "Fone Bluetooth",
    "category": "Eletrônicos",
    "description": "Acessório para ouvir música e atender chamadas.",
    "price": "Consulte o preço",
    "affiliateUrl": "",
    "symbol": "♫"
  },
  {
    "id": "eletro-02",
    "name": "Suporte para celular",
    "category": "Eletrônicos",
    "description": "Praticidade para apoiar o aparelho em diferentes situações.",
    "price": "Consulte o preço",
    "affiliateUrl": "",
    "symbol": "▣"
  },
  {
    "id": "beleza-01",
    "name": "Kit de cuidados pessoais",
    "category": "Beleza",
    "description": "Acessórios para sua rotina de autocuidado.",
    "price": "Consulte o preço",
    "affiliateUrl": "",
    "symbol": "✧"
  },
  {
    "id": "auto-01",
    "name": "Acessório automotivo",
    "category": "Automotivos",
    "description": "Uma opção útil para equipar e organizar seu veículo.",
    "price": "Consulte o preço",
    "affiliateUrl": "",
    "symbol": "⚙"
  },
  {
    "id": "moda-01",
    "name": "Relógio casual",
    "category": "Moda e acessórios",
    "description": "Acessório versátil para compor o visual.",
    "price": "Consulte o preço",
    "affiliateUrl": "",
    "symbol": "◷"
  },
  {
    "id": "lazer-01",
    "name": "Acessório fitness",
    "category": "Esporte e lazer",
    "description": "Item para acompanhar atividades e momentos de lazer.",
    "price": "Consulte o preço",
    "affiliateUrl": "",
    "symbol": "↗"
  }
];
